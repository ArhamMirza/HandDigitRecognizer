from flask import Flask, render_template, request, jsonify
import cv2
import base64
import io
from PIL import Image, ImageOps
import numpy as np
import torch
from DigitRecognitionModel import DigitRecognitionModel

app = Flask(__name__)

#loading state_dict for trained model
model_load = torch.load('digit_classification_model (1).pth',map_location=torch.device('cpu'))

# Create an instance of model
model_test = DigitRecognitionModel(input_shape=1, hidden_units=32, output_shape=10)

# Load the model's state_dict
model_test.load_state_dict(model_load)

@app.route('/')
def home():
    return render_template('index.html')  

@app.route('/predict', methods=['POST'])
def predict():
    #get the canvas image
    image_data = request.json['image']

    #decode the image for further processing
    image = Image.open(io.BytesIO(base64.b64decode(image_data.split(',')[1])))

    # Convert the PIL image to a numpy array
    image_array = np.array(image)
   
    #get grayscale image
    image_array = image_array[:,:,3]

    # Perform prediction using the processed image
    prediction,probabilities = process_image(image_array)

    #send the probabilities for each digit and final prediction to the page
    return jsonify({'prediction': str(prediction),'probabilities': probabilities})

#process the image to a suitable tensor for our CNN model
def process_image(image):#

    #resize to 28x28 as our cnn has been trained on images of this size 
    resized_image = cv2.resize(image, (28, 28),interpolation = cv2.INTER_LINEAR)
    
    #save image from canvas in local directory
    image_path = 'image'+str(0)+'.jpg'
    cv2.imwrite(image_path,resized_image)

    #turn into tensor
    image_tensor = torch.from_numpy(resized_image).float()
    image_tensor = image_tensor.unsqueeze(0)
    image_tensor = image_tensor.unsqueeze(0)
    
    #getting results from the model
    model_test.eval()
    with torch.inference_mode():
        test_pred = model_test(image_tensor)
      
    probabilities = torch.softmax(test_pred, dim=1)
    prediction =  torch.argmax(probabilities).item()
    probabilities = probabilities.tolist()[0]

    return prediction, probabilities



if __name__ == '__main__':
    app.run(debug=True)
