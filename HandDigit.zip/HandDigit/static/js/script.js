// Get the canvas element
const canvas = document.getElementById("canvas");
const canvasWidth = canvas.getAttribute("width");
const canvasHeight = canvas.getAttribute("height");

// Set the canvas size
canvas.width = canvasWidth;
canvas.height = canvasHeight;

// Get the 2D drawing context
const context = canvas.getContext("2d");

// Variables to keep track of drawing state
let isDrawing = false;
let undoStack = [];
let redoStack = [];
let paintWidth = 15;
let color = "black";
let selectedButton = null;
let selectPaint = null;
let selectWidth = null;

undoStack.push(context.getImageData(0, 0, canvas.width, canvas.height));

// Function to start drawing
function startDrawing(e) {
  isDrawing = true;
  const { offsetX, offsetY } = e;
  context.beginPath();
  context.moveTo(offsetX, offsetY);
}

// Function to draw
function draw(e) {
  if (!isDrawing) return;
  const { offsetX, offsetY } = e;
  context.lineTo(offsetX, offsetY);
  context.lineWidth = paintWidth;
  context.strokeStyle = color;
  context.stroke();
}

// Function to stop drawing
function stopDrawing() {
  if (isDrawing) {
    undoStack.push(context.getImageData(0, 0, canvas.width, canvas.height));
  }
  isDrawing = false;
}

// Function to clear the canvas
function clearCanvas() {
  context.clearRect(0, 0, canvas.width, canvas.height);
  undoStack = [];
  redoStack = [];
  undoStack.push(context.getImageData(0, 0, canvas.width, canvas.height));
}

// Function to undo drawing
function undoDrawing() {
  if (undoStack.length > 1) {
    redoStack.push(undoStack.pop());
    context.putImageData(undoStack[undoStack.length - 1], 0, 0);
  }
}

// Function to redo drawing
function redoDrawing() {
  if (redoStack.length > 0) {
    undoStack.push(redoStack.pop());
    context.putImageData(undoStack[undoStack.length - 1], 0, 0);
  }
}

function setToErase() {
  color = "white";
}

function setToPaint() {
  color = "black";
}

function setPaintWidth(width) {
  paintWidth = width;
}

function handleButtonClick(button, buttonGroup, activeClass) {
  if (buttonGroup) {
    buttonGroup.forEach((btn) => {
      btn.classList.remove(activeClass);
    });
  }
  button.classList.add(activeClass);
}

// Add event listeners
canvas.addEventListener("mousedown", startDrawing);
canvas.addEventListener("mousemove", draw);
canvas.addEventListener("mouseup", stopDrawing);
canvas.addEventListener("mouseout", stopDrawing);

const paintBtn = document.getElementById("paintBtn");
paintBtn.addEventListener("click", setToPaint);

const eraserBtn = document.getElementById("eraserBtn");
eraserBtn.addEventListener("click", setToErase);

const thinBtn = document.getElementById("thinBtn");
thinBtn.addEventListener("click", () => setPaintWidth(10));

const mediumBtn = document.getElementById("mediumBtn");
mediumBtn.addEventListener("click", () => setPaintWidth(20));

const thickBtn = document.getElementById("thickBtn");
thickBtn.addEventListener("click", () => setPaintWidth(40));

const clearBtn = document.getElementById("clearBtn");
clearBtn.addEventListener("click", clearCanvas);

const undoBtn = document.getElementById("undoBtn");
undoBtn.addEventListener("click", undoDrawing);

const redoBtn = document.getElementById("redoBtn");
redoBtn.addEventListener("click", redoDrawing);

const paintButtons = document.querySelectorAll(".paint");
const paintWidthButtons = document.querySelectorAll(".paint-width");

paintButtons.forEach((button) => {
  button.addEventListener("click", () => {
    handleButtonClick(button, paintButtons, "active");
  });
});

paintWidthButtons.forEach((button) => {
  button.addEventListener("click", () => {
    handleButtonClick(button, paintWidthButtons, "active");
  });
});

const defaultPaintButton = paintButtons[0];
const defaultPaintWidthButton = paintWidthButtons[1];
defaultPaintButton.classList.add("active");
defaultPaintWidthButton.classList.add("active");

function scrollScreen(percentage) {
  const windowHeight = window.innerHeight;
  const scrollHeight = document.documentElement.scrollHeight - windowHeight;
  const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;

  const targetScrollPosition = scrollPosition + (scrollHeight * (1 + percentage / 100));

  window.scrollTo({
    top: targetScrollPosition,
    behavior: "smooth" 
  });
}

function predictDigit() {
  const image = canvas.toDataURL("image/png");

  // Send the image to the server for prediction
  fetch("/predict", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      image: image
    })
  })
    .then((response) => response.json())
    .then((data) => {

      //getting data from flask server and displaying the results on front page
      const prediction = data.prediction;
      const probabilities = data.probabilities;
      const probabilityBarsDiv = document.getElementById("bar");
      const resultDiv = document.getElementById("result");

      resultDiv.innerHTML = `Results: The number is ${prediction}`;
      resultDiv.style.fontSize = "32px";

      scrollScreen(80);

      probabilityBarsDiv.innerHTML = "";

      // Creating probability bars and dynamically displaying them on front page
      //Structure is a box which contains 3 elements the digit on the left, bar in the middle and probability percentage on right
      //The bar contains a green colored bar. The length of the green bar indicated the probability
      for (let i = 0; i < probabilities.length; i++) {
        const box = document.createElement("div");
        const num = document.createElement("div");
        const bar = document.createElement("div");
        const probBar = document.createElement("div");
        const perc = document.createElement("div");

        //styling for the box
        box.style.width = "100%";
        box.style.color = "white";
        box.style.padding = "5px 5px 5px 5px";
        box.style.display = "flex";
        box.style.justifyContent = "space-between";
        box.style.flexDirection = "row";
        box.style.alignItems = "center";

        //styling for the digit
        num.style.width = "20px";
        num.innerHTML = i.toString();
        num.style.color = "white";

        //styling for the bar
        bar.style.width = "80%";
        bar.style.height = "20px";
        bar.style.backgroundColor = "white";
        bar.style.margin = "10px 10px 10px 10px";
        bar.style.borderRadius = "20px";

        var prob = probabilities[i] * 100;
        prob = prob.toFixed(2);

        //styling for the probability bar
        probBar.style.width = `${prob}%`;
        probBar.style.height = "100%";
        probBar.style.backgroundColor = "green";
        probBar.style.textAlign = "right";
        probBar.style.borderRadius = "10px 0px 0px 10px";
        probBar.style.paddingLeft = "10px";

        if (prob >= 99) {
          probBar.style.borderRadius = "10px";
        } else if (prob == 0) {
          probBar.style.backgroundColor = "white";
        }

        perc.innerHTML = `${prob}%`;
        perc.style.color = "white";
        perc.style.width = "20px";

        probabilityBarsDiv.appendChild(box);
        box.appendChild(num);
        box.appendChild(bar);
        bar.appendChild(probBar);
        box.appendChild(perc);
      }
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}
